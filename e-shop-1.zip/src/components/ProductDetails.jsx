import React from 'react'

function ProductDetails() {
  return (
    <div className='container'>
        <div className="row">
            <div className="col-md-12 text-center">
                <h3 className="display-3 text-sucess">Product Details</h3>
            </div>
        </div>
    </div>
  )
}

export default ProductDetails
