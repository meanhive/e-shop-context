import React from 'react'

function ProductCard() {
  return (
    <div>
        product card
    </div>
  )
}

export default ProductCard
