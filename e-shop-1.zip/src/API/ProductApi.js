import { useState, useMemo, useEffect } from 'react'
import axios from 'axios'

const url = `https://dummyjson.com`

function useProductApi() {
    const [products,setProducts]  = useState([])

    const readProducts = async () => {
        const out = await axios.get(`${url}/products`)
            setProducts(out.data.products)
    }

    const initValue = useMemo(() => (
        { value: [products,setProducts]}
    ))

    useEffect(() => {
       readProducts()
    },[])

  return {
    products: initValue
  }
}

export default useProductApi